#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 server.py --host 0.0.0.0
