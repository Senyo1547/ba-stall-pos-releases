#!/usr/bin/env python3
"""Small, same-origin shared store. No external packages. All token holders are trusted managers."""
import argparse
from datetime import datetime
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
MAX_BODY = 20_000_000
STATIC = {'/': ('index.html', 'text/html; charset=utf-8'), '/index.html': ('index.html', 'text/html; charset=utf-8'), '/app.js': ('app.js', 'text/javascript; charset=utf-8'), '/core.js': ('core.js', 'text/javascript; charset=utf-8'), '/style.css': ('style.css', 'text/css; charset=utf-8')}

def fresh():
    return {'schema': 3, 'settings': {'name': '摊位账本', 'wechat': '', 'alipay': ''}, 'products': [], 'orders': [], 'expenses': [], 'audit': []}

def check(v, msg):
    if not v:
        raise ValueError(msg)

def integer(n, minimum=0):
    return type(n) is int and minimum <= n <= 1_000_000_000

def image(v):
    return isinstance(v, str) and (v == '' or len(v) <= 1_500_000 and re.fullmatch(r'data:image/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+', v))

def timestamp(v):
    if not isinstance(v, str):
        return False
    try:
        datetime.fromisoformat(v.replace('Z', '+00:00'))
        return True
    except ValueError:
        return False

def validate(s):
    check(isinstance(s, dict) and s.get('schema') == 3, '备份版本无效')
    check(all(isinstance(s.get(k), list) for k in ('products', 'orders', 'expenses', 'audit')), '数据格式无效')
    t = s.get('settings', {})
    check(isinstance(t, dict) and isinstance(t.get('name'), str) and len(t['name']) <= 100 and image(t.get('wechat')) and image(t.get('alipay')), '设置无效')
    ids = set()
    for p in s['products']:
        check(isinstance(p, dict), '商品格式无效')
        pid = p.get('id')
        check(isinstance(pid, str) and re.fullmatch(r'[A-Za-z0-9_-]+', pid) and pid not in ids, '商品编号无效')
        ids.add(pid)
        check(isinstance(p.get('name'), str) and p['name'].strip() and len(p['name']) <= 200, '商品名称无效')
        check(isinstance(p.get('category'), str) and len(p['category']) <= 100 and isinstance(p.get('note'), str) and len(p['note']) <= 2000, '商品分类或备注无效')
        check(integer(p.get('price')) and type(p.get('stock')) is int and abs(p['stock']) <= 1_000_000_000 and image(p.get('image', '')), '价格、库存或图片无效')
        check(type(p.get('active')) is bool and isinstance(p.get('components'), list), '商品配置无效')
    by_id = {p['id']: p for p in s['products']}
    for p in s['products']:
        used = set()
        for c in p['components']:
            check(isinstance(c, dict) and c.get('id') in ids and c['id'] != p['id'] and c['id'] not in used and integer(c.get('qty'), 1) and not by_id[c['id']]['components'], '套装组件无效，不能嵌套套装')
            used.add(c['id'])
    order_ids = set()
    for o in s['orders']:
        check(isinstance(o, dict) and isinstance(o.get('id'), str) and o['id'] not in order_ids, '订单编号无效')
        order_ids.add(o['id'])
        check(o.get('status') in ('pending', 'paid', 'cancelled', 'refunded') and o.get('method') in ('微信', '支付宝', '现金') and integer(o.get('total')), '订单状态或金额无效')
        check(timestamp(o.get('createdAt')) and isinstance(o.get('operator'), str) and isinstance(o.get('lines'), list) and o['lines'] and isinstance(o.get('deductions'), list), '订单格式无效')
        check(all(isinstance(l, dict) and isinstance(l.get('name'), str) and integer(l.get('qty'), 1) and integer(l.get('total')) for l in o['lines']), '订单行无效')
        check(sum(l['total'] for l in o['lines']) == o['total'], '订单金额不一致')
        check(all(isinstance(d, dict) and d.get('id') in ids and integer(d.get('qty'), 1) for d in o['deductions']), '扣库明细无效')
    for e in s['expenses']:
        check(isinstance(e, dict) and isinstance(e.get('id'), str) and integer(e.get('amount'), 1) and isinstance(e.get('note'), str) and timestamp(e.get('createdAt')), '支出记录无效')
    check(all(isinstance(a, dict) and all(isinstance(a.get(k), str) for k in ('id', 'at', 'operator', 'action')) for a in s['audit']), '操作记录无效')
    return s

class Database:
    def __init__(self, path):
        self.path = path
        with self.connect() as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('CREATE TABLE IF NOT EXISTS store (id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL, body TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS history (revision INTEGER PRIMARY KEY, at TEXT DEFAULT CURRENT_TIMESTAMP, body TEXT NOT NULL)')
            db.execute('INSERT OR IGNORE INTO store VALUES (1,0,?)', (json.dumps(fresh(), ensure_ascii=False),))
    def connect(self):
        return sqlite3.connect(self.path, timeout=15)
    def read(self):
        with self.connect() as db:
            rev, body = db.execute('SELECT revision,body FROM store WHERE id=1').fetchone()
            return {'revision': rev, 'state': json.loads(body)}
    def write(self, revision, state):
        validate(state)
        body = json.dumps(state, ensure_ascii=False, separators=(',', ':'))
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            rev, old = db.execute('SELECT revision,body FROM store WHERE id=1').fetchone()
            if revision != rev:
                raise Conflict()
            db.execute('INSERT INTO history(revision,body) VALUES (?,?)', (rev, old))
            db.execute('DELETE FROM history WHERE revision < ?', (rev-19,))
            db.execute('UPDATE store SET revision=?,body=? WHERE id=1', (rev+1, body))
        return {'revision': rev+1, 'state': state}

class Conflict(Exception):
    pass

class Handler(BaseHTTPRequestHandler):
    server_version = 'StallStudio/2.0'
    def send(self, code, data, content_type='application/json; charset=utf-8'):
        raw = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
        self.end_headers()
        self.wfile.write(raw)
    def authenticated(self):
        provided = self.headers.get('Authorization', '')
        # Equal-length hashes keep Unicode / malformed input from causing compare failures.
        valid = hmac.compare_digest(hashlib.sha256(provided.encode()).digest(), hashlib.sha256(('Bearer '+self.server.token).encode()).digest())
        if not valid:
            self.send(401, {'error': '访问口令不正确或未登录'})
        return valid
    def do_GET(self):
        path = urlsplit(self.path).path
        if path == '/api/state':
            if self.authenticated():
                self.send(200, self.server.db.read())
        elif path in STATIC:
            filename, mime = STATIC[path]
            self.send(200, (ROOT / filename).read_bytes(), mime)
        else:
            self.send(404, {'error': '文件不存在'})
    def do_PUT(self):
        if urlsplit(self.path).path != '/api/state':
            return self.send(404, {'error': '接口不存在'})
        if not self.authenticated():
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            check(0 < length <= MAX_BODY, '请求过大或为空（上限 20MB）')
            payload = json.loads(self.rfile.read(length))
            check(isinstance(payload, dict) and integer(payload.get('revision')), '版本号无效')
            self.send(200, self.server.db.write(payload['revision'], payload.get('state')))
        except Conflict:
            self.send(409, {'error': '数据已被其他操作人更新，请刷新后重试'})
        except (ValueError, TypeError, KeyError, OverflowError):
            self.send(400, {'error': '数据格式或金额无效，未保存'})
        except sqlite3.Error:
            self.send(503, {'error': '数据库暂时不可用，请稍后再试'})
    def log_message(self, fmt, *args):
        # Never log headers or request bodies (access tokens and financial records).
        super().log_message(fmt, *args)

def main():
    parser = argparse.ArgumentParser(description='摊位账本共享服务')
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--data-dir', default=str(ROOT / '.data'))
    args = parser.parse_args()
    directory = Path(args.data_dir)
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    token_path = directory / 'access-token.txt'
    token = os.environ.get('STALL_TOKEN', '').strip()
    if not token:
        if not token_path.exists():
            token_path.write_text(secrets.token_urlsafe(24), encoding='utf-8')
            token_path.chmod(0o600)
        token = token_path.read_text(encoding='utf-8').strip()
    check(len(token) >= 12, '访问口令至少需要 12 个字符')
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.token = token
    server.db = Database(directory / 'stall.sqlite3')
    print(f'摊位账本已启动：http://{args.host}:{args.port}', flush=True)
    print(f'访问口令：{token}（仅提供给共同管理者）', flush=True)
    print('本机操作请点击「连接共享摊位」。多人使用需保持这台电脑运行。', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n已停止，数据已保存在 .data 文件夹。')
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
