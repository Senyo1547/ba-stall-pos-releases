/* Pure business rules shared by the interface and regression tests. Amounts are integer cents. */
(function(root){
'use strict';
const fresh=()=>({schema:3,settings:{name:'摊位账本',wechat:'',alipay:''},products:[],orders:[],expenses:[],audit:[]});
const clone=x=>JSON.parse(JSON.stringify(x));
const assert=(v,m)=>{if(!v)throw Error(m);};
const integer=(n,min=0)=>Number.isSafeInteger(n)&&n>=min&&n<=1000000000;
const image=v=>v===''||(/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v)&&v.length<=1500000);
function validate(s){
 assert(s&&s.schema===3&&s.settings&&Array.isArray(s.products)&&Array.isArray(s.orders)&&Array.isArray(s.expenses)&&Array.isArray(s.audit),'备份格式不正确');
 assert(typeof s.settings.name==='string'&&s.settings.name.length<=100,'摊位名称过长');
 assert(image(s.settings.wechat)&&image(s.settings.alipay),'收款码图片无效');
 const ids=new Set();
 for(const p of s.products){assert(typeof p.id==='string'&&/^[A-Za-z0-9_-]+$/.test(p.id)&&!ids.has(p.id),'商品编号重复或无效');ids.add(p.id);assert(typeof p.name==='string'&&p.name.trim()&&p.name.length<=200,'填写商品名称');assert(typeof p.category==='string'&&p.category.length<=100&&typeof p.note==='string'&&p.note.length<=2000,'分类或备注不正确');assert(integer(p.price)&&Number.isSafeInteger(p.stock)&&Math.abs(p.stock)<=1000000000,'价格和数量必须有效');assert(image(p.image||''),'商品图片无效');assert(Array.isArray(p.components)&&typeof p.active==='boolean','商品配置无效');const used=new Set();for(const c of p.components){assert(c.id!==p.id&&!used.has(c.id)&&integer(c.qty,1),'套装组件重复或数量不正确');used.add(c.id);}}
 for(const p of s.products)for(const c of p.components){const x=s.products.find(x=>x.id===c.id);assert(x&&!x.components.length,'套装只能包含普通商品');}
 const orderIds=new Set();for(const o of s.orders){assert(typeof o.id==='string'&&!orderIds.has(o.id),'订单编号重复');orderIds.add(o.id);assert(['pending','paid','cancelled','refunded'].includes(o.status)&&integer(o.total)&&Array.isArray(o.lines)&&o.lines.length&&Array.isArray(o.deductions)&&typeof o.createdAt==='string'&&Number.isFinite(Date.parse(o.createdAt))&&typeof o.operator==='string','订单数据无效');assert(['微信','支付宝','现金'].includes(o.method),'收款方式无效');assert(o.lines.every(l=>typeof l.name==='string'&&integer(l.qty,1)&&integer(l.total))&&o.lines.reduce((n,l)=>n+l.total,0)===o.total,'订单金额不一致');assert(o.deductions.every(d=>ids.has(d.id)&&integer(d.qty,1)),'订单扣库明细无效');}
 assert(s.audit.every(a=>a&&['id','at','operator','action'].every(k=>typeof a[k]==='string')),'操作记录无效');
 assert(s.expenses.every(e=>typeof e.id==='string'&&typeof e.note==='string'&&typeof e.createdAt==='string'&&Number.isFinite(Date.parse(e.createdAt))&&integer(e.amount,1)),'支出金额无效');return s;
}
function availability(s,p){return p.components.length?Math.min(...p.components.map(c=>Math.floor(s.products.find(x=>x.id===c.id).stock/c.qty))):p.stock;}
function checkout(s,cart,method,operator,id,now=new Date().toISOString()){
 assert(cart.length,'请先选商品');assert(['微信','支付宝','现金'].includes(method),'选择收款方式');assert(!s.orders.some(o=>o.id===id),'订单已保存');
 const deductions=new Map(),lines=[];let total=0;const seen=new Set();
 for(const l of cart){const p=s.products.find(x=>x.id===l.id);assert(p&&p.active&&integer(l.qty,1)&&!seen.has(l.id),'购物车商品无效');seen.add(l.id);const amount=p.price*l.qty;assert(integer(amount),'订单金额过大');lines.push({id:p.id,name:p.name,qty:l.qty,total:amount});total+=amount;for(const c of p.components.length?p.components:[{id:p.id,qty:1}])deductions.set(c.id,(deductions.get(c.id)||0)+c.qty*l.qty);}
 assert(integer(total),'订单金额过大');for(const [id,qty] of deductions){const p=s.products.find(x=>x.id===id);assert(p.stock>=qty,`库存不足：${p.name}`);}
 for(const [id,qty] of deductions)s.products.find(x=>x.id===id).stock-=qty;
 s.orders.unshift({id,createdAt:now,operator,method,total,lines,deductions:[...deductions].map(([id,qty])=>({id,qty})),status:'pending'});
}
function transition(s,id,next,operator,now=new Date().toISOString()){
 const o=s.orders.find(o=>o.id===id);assert(o,'订单不存在');assert((o.status==='pending'&&['paid','cancelled'].includes(next))||(o.status==='paid'&&next==='refunded'),'订单状态已变化，请刷新');
 if(['cancelled','refunded'].includes(next))for(const d of o.deductions)s.products.find(p=>p.id===d.id).stock+=d.qty;
 o.status=next;o.updatedAt=now;o.updatedBy=operator;if(next==='paid'){o.paidAt=now;o.paymentSource='人工确认';}if(next==='refunded')o.refundedAt=now;
}
function migrate(old){
 assert(old&&Array.isArray(old.inventory)&&Array.isArray(old.sales),'旧版备份格式不正确');const s=fresh();s.settings.name=old.settings?.stallName||s.settings.name;
 s.products=old.inventory.map(p=>({id:p.id,name:[p.character,p.outfit&&p.outfit!=='默认'?p.outfit:'',p.category].filter(Boolean).join(' · '),category:p.category||'未分类',price:Math.round((p.price||0)*100),stock:p.initialStock??0,note:p.remark||'',image:'',active:!p.hiddenFromPos,components:(p.components||[]).map(id=>({id,qty:1}))}));
 for(const a of old.adjustments||[]){const p=s.products.find(p=>p.id===a.itemId);if(p)p.stock+=a.qty;}
 const groups=new Map();for(const l of old.sales){const id=l.orderId||l.id;if(!groups.has(id))groups.set(id,[]);groups.get(id).push(l);}
 for(const [id,ls]of groups){const ds=new Map();for(const l of ls){const p=s.products.find(p=>p.id===l.itemId);assert(p,'旧版销售引用了未知商品');for(const c of p.components.length?p.components:[{id:p.id,qty:1}])ds.set(c.id,(ds.get(c.id)||0)+c.qty*l.qty);}
 for(const [pid,qty]of ds)s.products.find(p=>p.id===pid).stock-=qty;
 const lines=ls.map(l=>({id:l.itemId,name:l.itemName||l.itemId,qty:l.qty,total:Math.round(l.total*100)}));s.orders.push({id,createdAt:ls[0].createdAt||`${ls[0].date}T12:00:00+08:00`,operator:'旧版导入',method:ls[0].method,total:lines.reduce((n,l)=>n+l.total,0),status:ls.every(l=>l.confirmed)?'paid':'pending',paymentSource:'旧版人工记录',lines,deductions:[...ds].map(([id,qty])=>({id,qty}))});}
 s.legacyReconciliation=old.reconciliation||{};return validate(s);
}
const api={fresh,clone,validate,availability,checkout,transition,migrate};if(typeof module!=='undefined')module.exports=api;root.StoreCore=api;
})(typeof globalThis!=='undefined'?globalThis:this);
